//server.js
require("dotenv").config();
const express = require('express'); //import framework
const app = express();              // create app instance
const PORT = process.env.PORT;                 // Config port (env var later)
const path = require('path'); 

app.use(express.json());

//a custom middleware that logs every request
app.use((req, res, next) => {
    // logs every request
    console.log(`${req.method} ${req.url} - ${new Date()}`);
    next(); // Pass to next handler (required!)
});


// GET that returns 'MY WEEK 2 API!'
app.get("/", (req, res) => {     // Route: GET / (home) - No more if/else!
    res.send("<h1>My Week 2 API!</h1>"); //Response: HTML or text (headers auto!)
    //res.json({ message: "JSON response"}); // Alternative: JSON

});

//Accepts {name, email}; responds 'Hello, [name]!'
app.post('/user', (req, res) => {
    const { name, email } = req.body;
    if (!name || !email) return res.status(400).json({error: 'Missing data' });
    // Simulate DB save
    res.status(201).json({ message: `Hello,: ${name}!` });
});

// to get a particular user ID and print 'User [id] profile'
app.get('/user/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
//validate id first
    if (!id || isNaN(id)) {
        return res.status(400).json({ error: 'Invalid user ID' });
    }
    // then res.send (id);
    res.json({ message: `User ${id} profile` });
});

// use curl/Postman; serve a static HTML page at /. 
// I already have app.get defined for homepage (/) defined earlier,
// So I used /about for this task instead.
app.get('/about', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});



app.listen(PORT, () => {        //start server
    console.log('Server running on http://localhost:$(PORT)');
});